package com.pocketforge3d

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

private data class SceneObject(
    val name: String,
    var x: Float = 0f, var y: Float = 0f, var z: Float = 0f,
    var rx: Float = 0f, var ry: Float = 0f, var rz: Float = 0f,
    var sx: Float = 1f, var sy: Float = 1f, var sz: Float = 1f
)

class SceneRenderer : GLSurfaceView.Renderer {
    private val objects = mutableListOf(SceneObject("Cube"))
    @Volatile private var selected = 0
    @Volatile private var yaw = 35f
    @Volatile private var pitch = 24f
    @Volatile private var cameraDistance = 7.5f
    private var program = 0
    private var positionHandle = 0
    private var colorHandle = 0
    private var mvpHandle = 0
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private val pv = FloatArray(16)
    private val vertices = floatBuffer(CUBE_VERTICES)
    private val edgeBuffer = floatBuffer(CUBE_EDGES)
    private val gridVertices = floatBuffer(makeGrid())
    private val axisVertices = floatBuffer(floatArrayOf(
        -5f, 0f, 0f, 5f, 0f, 0f,
        0f, -0.01f, -5f, 0f, -0.01f, 5f,
        0f, 0f, 0f, 0f, 2f, 0f
    ))

    @Synchronized fun addCube() { objects.add(SceneObject("Cube ${objects.size + 1}", x = ((objects.size % 3) - 1) * 1.25f, z = (objects.size / 3) * 1.25f)); selected = objects.lastIndex }
    @Synchronized fun objectCount() = objects.size
    @Synchronized fun objectNames() = objects.map { it.name }
    @Synchronized fun selectObject(index: Int) { if (index in objects.indices) selected = index }
    @Synchronized fun moveSelected() { objects.getOrNull(selected)?.let { it.x += 0.25f } }
    @Synchronized fun rotateSelected() { objects.getOrNull(selected)?.let { it.ry += 15f } }
    @Synchronized fun scaleSelected() { objects.getOrNull(selected)?.let { val next = (it.sx + 0.1f).coerceAtMost(2.5f); it.sx = next; it.sy = next; it.sz = next } }
    fun orbit(dx: Float, dy: Float) { yaw += dx * 0.45f; pitch = (pitch + dy * 0.35f).coerceIn(-75f, 75f) }
    fun zoom(delta: Float) { cameraDistance = (cameraDistance + delta * 0.012f).coerceIn(3f, 18f) }
    fun resetCamera() { yaw = 35f; pitch = 24f; cameraDistance = 7.5f }

    @Synchronized fun toJson(): JSONObject {
        val arr = JSONArray()
        objects.forEach { o -> arr.put(JSONObject().apply {
            put("name", o.name); put("position", JSONArray().put(o.x).put(o.y).put(o.z))
            put("rotation", JSONArray().put(o.rx).put(o.ry).put(o.rz))
            put("scale", JSONArray().put(o.sx).put(o.sy).put(o.sz))
        }) }
        return JSONObject().put("format", "PocketForge3D").put("version", 1).put("objects", arr)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.055f, 0.075f, 0.095f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        val vertexShader = """
            uniform mat4 uMVP;
            attribute vec3 aPosition;
            void main() { gl_Position = uMVP * vec4(aPosition, 1.0); }
        """.trimIndent()
        val fragmentShader = """
            precision mediump float;
            uniform vec4 uColor;
            void main() { gl_FragColor = uColor; }
        """.trimIndent()
        program = GLES20.glCreateProgram().also { p ->
            GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vertexShader))
            GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fragmentShader))
            GLES20.glLinkProgram(p)
        }
        positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        colorHandle = GLES20.glGetUniformLocation(program, "uColor")
        mvpHandle = GLES20.glGetUniformLocation(program, "uMVP")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height.coerceAtLeast(1)
        Matrix.perspectiveM(projection, 0, 48f, ratio, 0.1f, 100f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val yr = Math.toRadians(yaw.toDouble()).toFloat()
        val pr = Math.toRadians(pitch.toDouble()).toFloat()
        val cx = cameraDistance * cos(pr) * sin(yr)
        val cy = cameraDistance * sin(pr)
        val cz = cameraDistance * cos(pr) * cos(yr)
        Matrix.setLookAtM(view, 0, cx, cy, cz, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.setIdentityM(model, 0)
        drawLines(gridVertices, gridVertices.capacity() / 3, floatArrayOf(0.20f, 0.25f, 0.30f, 1f))
        drawLines(axisVertices, 6, floatArrayOf(0.35f, 0.48f, 0.55f, 1f))
        synchronized(this) {
            objects.forEachIndexed { index, o ->
                Matrix.setIdentityM(model, 0)
                Matrix.translateM(model, 0, o.x, o.y, o.z)
                Matrix.rotateM(model, 0, o.rx, 1f, 0f, 0f)
                Matrix.rotateM(model, 0, o.ry, 0f, 1f, 0f)
                Matrix.rotateM(model, 0, o.rz, 0f, 0f, 1f)
                Matrix.scaleM(model, 0, o.sx, o.sy, o.sz)
                setMvp()
                val c = if (index == selected) floatArrayOf(0.38f, 0.88f, 0.78f, 1f) else floatArrayOf(0.46f, 0.61f, 0.72f, 1f)
                GLES20.glUniform4fv(colorHandle, 1, c, 0)
                vertices.position(0)
                GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, vertices)
                GLES20.glEnableVertexAttribArray(positionHandle)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, CUBE_VERTICES.size / 3)
                GLES20.glDisableVertexAttribArray(positionHandle)
                drawObjectEdges(o, index == selected)
            }
        }
    }

    private fun drawObjectEdges(o: SceneObject, selected: Boolean) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, o.x, o.y, o.z)
        Matrix.rotateM(model, 0, o.rx, 1f, 0f, 0f); Matrix.rotateM(model, 0, o.ry, 0f, 1f, 0f); Matrix.rotateM(model, 0, o.rz, 0f, 0f, 1f)
        Matrix.scaleM(model, 0, o.sx * 1.003f, o.sy * 1.003f, o.sz * 1.003f)
        setMvp()
        GLES20.glUniform4fv(colorHandle, 1, if (selected) floatArrayOf(0.83f, 1f, 0.95f, 1f) else floatArrayOf(0.17f, 0.25f, 0.31f, 1f), 0)
        edgeBuffer.position(0)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, edgeBuffer)
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glLineWidth(if (selected) 2.2f else 1f)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, CUBE_EDGES.size / 3)
        GLES20.glDisableVertexAttribArray(positionHandle)
    }

    private fun drawLines(buffer: FloatBuffer, count: Int, color: FloatArray) {
        Matrix.setIdentityM(model, 0); setMvp()
        GLES20.glUniform4fv(colorHandle, 1, color, 0)
        buffer.position(0)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, buffer)
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, count)
        GLES20.glDisableVertexAttribArray(positionHandle)
    }

    private fun setMvp() {
        Matrix.multiplyMM(pv, 0, projection, 0, view, 0)
        Matrix.multiplyMM(mvp, 0, pv, 0, model, 0)
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvp, 0)
    }

    private fun compile(type: Int, source: String): Int = GLES20.glCreateShader(type).also {
        GLES20.glShaderSource(it, source); GLES20.glCompileShader(it)
    }

    private fun floatBuffer(data: FloatArray): FloatBuffer = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(data); position(0) }

    companion object {
        private val CUBE_VERTICES = floatArrayOf(
            -1f,-1f,1f, 1f,-1f,1f, 1f,1f,1f, -1f,-1f,1f, 1f,1f,1f, -1f,1f,1f,
            1f,-1f,-1f, -1f,-1f,-1f, -1f,1f,-1f, 1f,-1f,-1f, -1f,1f,-1f, 1f,1f,-1f,
            -1f,-1f,-1f, -1f,-1f,1f, -1f,1f,1f, -1f,-1f,-1f, -1f,1f,1f, -1f,1f,-1f,
            1f,-1f,1f, 1f,-1f,-1f, 1f,1f,-1f, 1f,-1f,1f, 1f,1f,-1f, 1f,1f,1f,
            -1f,1f,1f, 1f,1f,1f, 1f,1f,-1f, -1f,1f,1f, 1f,1f,-1f, -1f,1f,-1f,
            -1f,-1f,-1f, 1f,-1f,-1f, 1f,-1f,1f, -1f,-1f,-1f, 1f,-1f,1f, -1f,-1f,1f
        )
        private val CUBE_EDGES = floatArrayOf(
            -1f,-1f,-1f, 1f,-1f,-1f, 1f,-1f,-1f, 1f,1f,-1f, 1f,1f,-1f, -1f,1f,-1f, -1f,1f,-1f, -1f,-1f,-1f,
            -1f,-1f,1f, 1f,-1f,1f, 1f,-1f,1f, 1f,1f,1f, 1f,1f,1f, -1f,1f,1f, -1f,1f,1f, -1f,-1f,1f,
            -1f,-1f,-1f, -1f,-1f,1f, 1f,-1f,-1f, 1f,-1f,1f, 1f,1f,-1f, 1f,1f,1f, -1f,1f,-1f, -1f,1f,1f
        )
        private fun makeGrid(): FloatArray {
            val out = ArrayList<Float>()
            for (i in -10..10) {
                out.add(i.toFloat()); out.add(-0.03f); out.add(-10f)
                out.add(i.toFloat()); out.add(-0.03f); out.add(10f)
                out.add(-10f); out.add(-0.03f); out.add(i.toFloat())
                out.add(10f); out.add(-0.03f); out.add(i.toFloat())
            }
            return out.toFloatArray()
        }
    }
}
