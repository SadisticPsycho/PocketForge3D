package com.pocketforge3d

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var surface: EditorSurface
    private lateinit var renderer: SceneRenderer
    private lateinit var countLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 21, 27)
        window.navigationBarColor = Color.rgb(16, 21, 27)

        renderer = SceneRenderer()
        surface = EditorSurface(this, renderer)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 21, 27))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Color.rgb(23, 30, 38))
        }
        val title = TextView(this).apply {
            text = "POCKETFORGE  /  3D"
            textSize = 16f
            setTextColor(Color.rgb(235, 243, 247))
            letterSpacing = 0.06f
        }
        countLabel = TextView(this).apply {
            text = "1 object"
            textSize = 12f
            setTextColor(Color.rgb(121, 214, 197))
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(36), 1f))
        header.addView(countLabel, LinearLayout.LayoutParams(dp(95), dp(36)))
        root.addView(header)
        root.addView(surface, LinearLayout.LayoutParams(-1, 0, 1f))

        val hint = TextView(this).apply {
            text = "DRAG to orbit   •   PINCH to zoom   •   Add and transform objects below"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(151, 166, 180))
            setPadding(dp(8), dp(9), dp(8), dp(9))
            setBackgroundColor(Color.rgb(20, 26, 33))
        }
        root.addView(hint)
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(23, 30, 38))
        }
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        tools.addView(toolButton("＋ Cube") { renderer.addCube(); refreshCount() })
        tools.addView(toolButton("Move +") { renderer.moveSelected(); toast("Moved selected object") })
        tools.addView(toolButton("Rotate +") { renderer.rotateSelected(); toast("Rotated selected object") })
        tools.addView(toolButton("Scale +") { renderer.scaleSelected(); toast("Scaled selected object") })
        tools.addView(toolButton("Objects") { showObjects() })
        tools.addView(toolButton("Save") { saveScene() })
        tools.addView(toolButton("Reset view") { renderer.resetCamera() })
        scroll.addView(tools)
        root.addView(scroll)
        setContentView(root)
    }

    private fun toolButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.rgb(226, 238, 242))
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(43, 57, 68))
        setPadding(dp(10), 0, dp(10), 0)
        layoutParams = LinearLayout.LayoutParams(-2, dp(44)).apply { marginEnd = dp(6) }
        setOnClickListener { action() }
    }

    private fun refreshCount() {
        val n = renderer.objectCount()
        countLabel.text = "$n object${if (n == 1) "" else "s"}"
    }

    private fun showObjects() {
        val names = renderer.objectNames().toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Scene objects")
            .setItems(names) { _, which -> renderer.selectObject(which); toast("Selected ${names[which]}") }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun saveScene() {
        try {
            val file = File(filesDir, "pocketforge_scene.json")
            file.writeText(renderer.toJson().toString(2))
            Toast.makeText(this, "Scene saved locally", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onPause() { super.onPause(); surface.onPause() }
    override fun onResume() { super.onResume(); surface.onResume() }
}

private class EditorSurface(context: android.content.Context, private val scene: SceneRenderer) : GLSurfaceView(context) {
    private var previousX = 0f
    private var previousY = 0f
    private var previousDistance = 0f

    init {
        setEGLContextClientVersion(2)
        setRenderer(scene)
        renderMode = RENDERMODE_CONTINUOUSLY
        setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { previousX = event.x; previousY = event.y; previousDistance = 0f }
                MotionEvent.ACTION_POINTER_DOWN -> if (event.pointerCount >= 2) previousDistance = distance(event)
                MotionEvent.ACTION_MOVE -> {
                    if (event.pointerCount >= 2) {
                        val d = distance(event)
                        if (previousDistance > 0f && d > 0f) scene.zoom(previousDistance - d)
                        previousDistance = d
                    } else {
                        scene.orbit(event.x - previousX, event.y - previousY)
                    }
                    previousX = event.x; previousY = event.y
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> previousDistance = 0f
            }
            true
        }
    }

    private fun distance(e: MotionEvent): Float {
        val dx = e.getX(0) - e.getX(1)
        val dy = e.getY(0) - e.getY(1)
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }
}
