# PocketForge 3D (prototype)

PocketForge 3D is an early Android 3D editor prototype. The current source includes a basic OpenGL ES viewport and initial touch/editor interactions. It is not yet a Blender replacement; mesh editing, undo/redo, robust project loading, materials, animation, sculpting, and GLB export remain future work.

## Build without a PC (GitHub Actions)

This project includes `.github/workflows/android.yml` to build a debug APK on a cloud runner.

1. Download and extract this ZIP on your phone.
2. In GitHub's mobile website, create a new **public or private repository** named `PocketForge3D`.
3. Upload the **contents** of this folder (including the hidden `.github` folder and its workflow file) to the repository root. Make sure `.github/workflows/android.yml` is included. If GitHub's mobile upload flow hides dot-folders or makes folder upload awkward, use GitHub's web file editor to create `.github/workflows/android.yml` and paste the workflow contents from this ZIP.
4. Open the repository's **Actions** tab. If prompted, enable Actions.
5. Select **Build PocketForge 3D APK**, tap **Run workflow**, and start it on the default branch. A push to `main` or `master` also starts a build automatically.
6. When the run finishes successfully, open it, scroll to **Artifacts**, and download `PocketForge3D-debug-apk`. Extract the downloaded artifact ZIP to get the `.apk`.
7. Open the APK on your phone and approve installation if Android asks. Only install APKs you built or trust.

The workflow uses Java 17 and Gradle 8.9 on GitHub's Linux runner. The first run has not been verified in this environment, so check the Actions log for any build errors.

## Local build

With a compatible Android SDK and JDK 17 installed, run `gradle assembleDebug` from the project root. The APK should be at `app/build/outputs/apk/debug/app-debug.apk`.
